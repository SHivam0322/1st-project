from bs4 import BeautifulSoup
from pymongo import MongoClient
import re
import requests


headers = requests.utils.default_headers()
headers.update({ 'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0'})

for i in range(2):
    print("Iteration " + str(i+1) + " started...")
    url = "https://www.indeed.co.in/jobs?q=content+writer&l=India&start="+str(10*i)
    print("url>>>>>>>>>>>",url)
    # url = "https://www.indeed.co.in/jobs?q=content+writer&l=India&start=0"
    req = requests.get(url, headers)
    soup = BeautifulSoup(req.content, 'html.parser')

    client = MongoClient('localhost:27017')
    db = client.indeedJobs
    coll = db.mails

    # htmlfile = open('testJobs.html', 'r')
    # html_doc = htmlfile.read()
    # soup = BeautifulSoup(html_doc, 'html.parser')
    # print(soup.prettify())
    # print(soup.text)
    # res = soup.find_all(class_="company")
    res = soup.find_all("div", class_="jobsearch-SerpJobCard")
    companies = []
    print("Job count before data formation:",len(res))
    print("Creating job data...")
    for item in res:
        job = {}
        job['comapny'] = ''.join(item.find(class_="company").getText().strip()) if item.find(class_="company") else ''
        job['location'] = re.sub(r"[^a-zA-Z0-9()-/@]+", ' ',item.find(class_="location accessible-contrast-color-location").getText().rstrip()) if item.find(class_="location accessible-contrast-color-location") else ''
        job['title'] = item.find(class_="jobtitle").get('title') if item.find(class_="jobtitle") else ''
        job['salary'] = item.find(class_="salaryText").getText().strip() if item.find(class_="salaryText") else ''
        job['link_1'] = 'https://www.indeed.co.in' + item.find(class_="jobtitle").get('href') if item.find(class_="jobtitle") else ''
        job['link_2'] = ''
        job['experience'] = ''
        job['source'] = 'indeed'
        job['description'] = item.find("div", class_="summary").getText().strip() if item.find("div", class_="summary") else ''
        companies.append(job)
        # print(job)
        # break
    print("Job data creation ended...")
    print("Total jobs:", len(companies))

    print("Inserting job data in db...")
    result = coll.insert_many(companies)
    if len(res) > -1:
        print("Data insertion completed...")
    # print(companies)
    # print(i)
