import pika
from bs4 import BeautifulSoup
import requests
from dotenv import load_dotenv
import os
import json
import schedule 
import time
# from lib import sendMail

load_dotenv()

def fetchData():
    try:
    # print("hi")
        jobsJson = open('../jsonFiles/shineJobs.json', 'r')
        jobsData = json.loads(jobsJson.read())
        for items in jobsData['jobs']:
            # print ("Start : %s" % time.ctime())
            headers = requests.utils.default_headers()
            headers.update({ 'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0'})

            connection = pika.BlockingConnection(
                pika.ConnectionParameters(host='localhost'))
            channel = connection.channel()
            for i in range(int(os.getenv("SHINE_PAGE_LIMIT") or 2)):
                print("Iteration " + str(i+1) + " started...")
                url = items['url']+str(i+1)
                req = requests.get(url, headers)
                # soup = BeautifulSoup(req.content, 'html.parser')
                body = req.content

                channel.queue_declare(queue='shineHtmlParse')
                channel.basic_publish(exchange='', routing_key='shineHtmlParse', body=body)
                print(str(i+1)+" Shine......... iteration data sent to consumer!...")
            connection.close()
            time.sleep(int(os.getenv("HTML_FETCH_SLEEP_TIME")) or 60*15)

    except Exception as e:
        error = {
            "status": "Shine......... Error occured while fetching html",
            # "requestUrl": url,
            "errorMsg": e
        }
        print("Error: ",error)
        # message = 'Subject: {}\n\n{}'.format("Gigs4me Job Error", error)
        # mailSent = sendMail(message)
        # print('Main sent: {}'.format(mailSent))

# schedule.every(1).minutes.do(fetchData) 
schedule.every().day.at("08:00").do(fetchData)

while True: 
  
    # Checks whether a scheduled task  
    # is pending to run or not 
    schedule.run_pending() 
    time.sleep(1) 
