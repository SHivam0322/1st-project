import pika
from bs4 import BeautifulSoup
import requests
from dotenv import load_dotenv
import os
import time
import schedule 
import json
# from lib import sendMail

load_dotenv()

def fetchData():
    try:
        jobsJson = open('../jsonFiles/indeedJobs.json', 'r')
        jobsData = json.loads(jobsJson.read())
        # print("jobsData>>>>>>",jobsData)
        for items in jobsData['jobs']:
            headers = requests.utils.default_headers()
            headers.update({ 'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0'})

            connection = pika.BlockingConnection(
                pika.ConnectionParameters(host='localhost'))
            channel = connection.channel()


            for i in range(int(os.getenv("INDEED_PAGE_LIMIT") ) or 2):
                print("Iteration " + str(i+1) + " started...")
                url = items['url']+str(10*i)
                # print("url>>>>>>",url)
                req = requests.get(url, headers)
                # soup = BeautifulSoup(req.content, 'html.parser')
                body = req.content

                channel.queue_declare(queue='indeedHtmlParse')
                channel.basic_publish(exchange='', routing_key='indeedHtmlParse', body=body)
                print(str(i+1)+" Indeed........... iteration data sent to consumer!...")

            connection.close()
            time.sleep(int(os.getenv("HTML_FETCH_SLEEP_TIME")) or 60*15)
        
    except Exception as e:
        error = {
            "status": "Indeed........... Error occured while fetching html",
            # "requestUrl": url,
            "errorMsg": e
        }
        print("Error: ",error)
        # message = 'Subject: {}\n\n{}'.format("Gigs4me Job Error", error)
        # mailSent = sendMail(message)
        # print('Main sent: {}'.format(mailSent))

schedule.every().day.at("08:00").do(fetchData)

while True: 
  
    # Checks whether a scheduled task  
    # is pending to run or not 
    schedule.run_pending() 
    time.sleep(1) 
