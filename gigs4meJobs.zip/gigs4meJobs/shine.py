
from bs4 import BeautifulSoup
from pymongo import MongoClient
import re
import requests
# import json
# import time

# jobsJson = open('jobs.json', 'r')
# jobsData = jobsJson.read()
# data4 = json.loads(jobsData)
# print("json>>>>>>>>",data4)
# print("json>>>>>>>>",type(data4))
# # print("jobsData>>>>>>>>",jobsData['jobs'])
# print("data>>>>>>>>",data4['jobs'])

# for item2 in data4['jobs']:
#     print(item2)


headers = requests.utils.default_headers()
headers.update({ 'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0'})

for i in range(1):
    print("Iteration " + str(i+1) + " started...")
    url = "https://www.shine.com/job-search/content-writing-jobs-in-india-"+str(i+1)
    req = requests.get(url, headers)
    soup = BeautifulSoup(req.content, 'html.parser')
    # print(soup.prettify())

    client = MongoClient('localhost:27017')
    db = client.shineJobs
    coll = db.mails

    # htmlfile = open('linkedin.html', 'r')
    # html_doc = htmlfile.read()
    # soup = BeautifulSoup(html_doc, 'html.parser')
    # # print(soup.prettify())
    # # print(soup.text)
    # res = soup.find_all(class_="company")
    res = soup.find_all("li", class_="search_listingleft search_listingleft_100")
    companies = []
    print("Job count before data formation:",len(res))
    # print("Creating job data...")
    j = 0
    for item in res:
        j = j+1
        if i == 1 and j > 1 or i !=1:
            # print(j)
            job = {}
            job['title'] = item.find("li",class_="snp cls_jobtitle").getText().strip() if item.find("li",class_="snp cls_jobtitle") else ''
            job['comapny'] = item.find("li",class_="snp_cnm cls_cmpname cls_jobcompany").getText().strip() if item.find("li",class_="snp_cnm cls_cmpname cls_jobcompany") else ''
            job['experience'] = item.find("span", class_="snp_yoe cls_jobexperience").getText().strip() if item.find("span", class_="snp_yoe cls_jobexperience") else ''
            job['description'] = item.find("li", class_="srcresult").getText().strip() if item.find("li", class_="srcresult") else ''
            job['location'] = item.find("em", class_="snp_loc").getText().strip() if item.find("em", class_="snp_loc") else ''
            job['link_1'] = "https://www.shine.com" + item.find("a", class_="cls_searchresult_a searchresult_link").get('href') if item.find("a", class_="cls_searchresult_a searchresult_link") else ''
            job['link_2'] = ''
            job['salary'] = ''
            skillsData = item.find(["div", "sk jsrp cls_jobskill"]) if item.find(["div", "sk jsrp cls_jobskill"]) else ''
            if len(skillsData) > 0:
                spans = skillsData.find_all('span') if skillsData.find_all('span') else ''
                if len(spans) > -1:
                    skills = []
                    for span in spans:
                        skills.append(span.getText().strip())
                    skills.pop(0)
            job['skills'] = skills
            companies.append(job)
    #     # print(job)
        # break
    print("Job data creation ended...")
    print("Total jobs:", len(companies))
    print("Inserting job data in db...")
    result = coll.insert_many(companies)
    if len(res) > -1:
        print("Data insertion completed...")
    print("total companies:", companies)