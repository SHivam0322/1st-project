from elasticsearch import Elasticsearch as ES 
from elasticsearch import helpers
from pymongo import MongoClient
import json
from bson import ObjectId

mongo_client = MongoClient('localhost:27017')
db = mongo_client.gigs4me
coll = db.Jobs
es = ES("localhost:9200")

class JSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)   
        return json.JSONEncoder.default(self, o)

actions = []
data = coll.find()
i = 0

for row in data:
    i += 1     
    # print("type::", type(row))  
    row['job_id'] = row['_id']   
    del row['_id']    
    elem = JSONEncoder().encode(row)    
    actions.append({   
        "_op_type": "index",        
        "_index": "jobs",        
        "_type": "_doc",        
        "_source": elem      
    })
    
index = helpers.bulk(es, actions, index="jobs", doc_type="_doc")
print("index::", index)