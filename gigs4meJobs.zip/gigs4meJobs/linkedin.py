from bs4 import BeautifulSoup
from pymongo import MongoClient
import re
import requests


headers = requests.utils.default_headers()
headers.update({ 'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0'})

for i in range(2):
    print("Iteration " + str(i+1) + " started...")
    url = "https://www.linkedin.com/jobs/search/?geoId=102713980&keywords=content%20writing&location=India&start="+str(25*i)
    # https://www.linkedin.com/jobs/search/?keywords=software%20developer&location=gurgaon&start=0
    # url = "https://www.indeed.co.in/Content-Writer-jobs-in-Chandigarh,-Chandigarh"
    req = requests.get(url, headers)
    soup = BeautifulSoup(req.content, 'html.parser')
    # print(soup.prettify())


    client = MongoClient('localhost:27017')
    db = client.linkedin
    coll = db.jobs

    # htmlfile = open('linkedin.html', 'r')
    # html_doc = htmlfile.read()
    # soup = BeautifulSoup(html_doc, 'html.parser')
    # # print(soup.prettify())
    #print(soup.text)
    # res = soup.find_all(class_="company")
    res = soup.find_all("li", class_="job-result-card")
    # print("res>>>>>>>>>>>.",res)
    companies = []
    print("Job count before data formation:",len(res))
    print("Creating job data...")
    for item in res:
        # print("item>>>>>>",item)
        # print("i:",i)
        i = i+1
        job = {}
        job['title'] = item.find(class_="result-card__title").getText().strip() if item.find(class_="result-card__title") else ''
        job['comapny'] = item.find("h4",class_="result-card__subtitle").getText().strip() if item.find("h4",class_="result-card__subtitle") else ''
        job['location'] = item.find("span", class_="job-result-card__location").getText().strip() if item.find("span", class_="job-result-card__location") else ''
        job['link_1'] = item.find("a", class_="result-card__full-card-link").get('href') if item.find("a", class_="result-card__full-card-link") else ''
        job['link_2'] = item.find("a", class_="job-result-card__subtitle-link").get('href') if item.find("a", class_="job-result-card__subtitle-link") else ''
        job['salary'] = ''
        job['experience'] = ''
        req2 = requests.get(job['link_1'], headers)
        soup2 = BeautifulSoup(req2.content, 'html.parser') 
        jobDescription = soup2.find("div", class_="description__text description__text--rich").getText().strip() if soup2.find("div", class_="description__text description__text--rich") else ''
        # print(soup2.prettify())
        job['description'] = jobDescription
        
        companies.append(job)
        # print(job)
        # break
    

    print("Job data creation ended...")
    print("Total jobs:", len(companies))
    print("Inserting job data in db...")
    result = coll.insert_many(companies)
    if len(res) > -1:
        print("Data insertion completed...")
    print("total companies:", len(companies))