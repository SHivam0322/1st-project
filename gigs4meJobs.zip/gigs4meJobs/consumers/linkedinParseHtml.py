from bs4 import BeautifulSoup
import pika
import json
# from lib import sendMail

try:
    connection = pika.BlockingConnection(
        pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    channel.queue_declare(queue='wixJobsSave')
    channel.queue_declare(queue='mongoJobsSave')
    channel.queue_declare(queue='linkedinHtmlParse')
    # channel.queue_declare(queue='linkedinFetchJobDetails')


    def callback(ch, method, properties, body):
        # print(" [x] Received %r" % body)
        soup = BeautifulSoup(body, 'html.parser')
        res = soup.find_all("li", class_="job-result-card")
        print("Job count before data formation:",len(res))
        print("Creating job data...")
        for item in res:
            job = {}
            job['title'] = item.find(class_="result-card__title").getText().strip() if item.find(class_="result-card__title") else ''
            job['company'] = item.find("h4",class_="result-card__subtitle").getText().strip() if item.find("h4",class_="result-card__subtitle") else ''
            job['location'] = item.find("span", class_="job-result-card__location").getText().strip() if item.find("span", class_="job-result-card__location") else ''
            job['job_link'] = item.find("a", class_="result-card__full-card-link").get('href') if item.find("a", class_="result-card__full-card-link") else ''
            job['link_2'] = item.find("a", class_="job-result-card__subtitle-link").get('href') if item.find("a", class_="job-result-card__subtitle-link") else ''
            job['description'] = ''
            job['salary'] = ''
            job['experience'] = ''
            job['source'] = 'linkedin'

            # channel.basic_publish(exchange='', routing_key='linkedinFetchJobDetails', body=json.dumps(job))
            if len(job['description']) > 0:
                channel.basic_publish(exchange='', routing_key='nlp', body=json.dumps(job))
            else:
                channel.basic_publish(exchange='', routing_key='mongoJobsSave', body=json.dumps(job))
                channel.basic_publish(exchange='', routing_key='wixJobsSave', body=json.dumps(job))


    channel.basic_consume(
        queue='linkedinHtmlParse', on_message_callback=callback, auto_ack=True)

    print(' [*] Waiting for messages. To exit press CTRL+C')
    channel.start_consuming()
except Exception as e:
    error = {
        "status": "Linkedin......... Error occured while parsgin html",
        "errorMsg": e
    }
    print("Error: ",error)
    # message = 'Subject: {}\n\n{}'.format("Gigs4me Job Error", error)
    # mailSent = sendMail(message)
    # print('Main sent: {}'.format(mailSent))
