import pika
import json
from pymongo import MongoClient
from datetime import datetime
# from lib import sendMail


try:
    connection = pika.BlockingConnection(
        pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    channel.queue_declare(queue='mongoJobsSave')

    client = MongoClient('localhost:27017')
    db = client.gigs4me
    coll = db.Jobs

    def callback(ch, method, properties, body):
        # print(" [x] Received %r" % json.loads(body))
        payload = json.loads(body)
        print(payload)
        # print(type(payload))
        payload['date'] = datetime.today().strftime('%Y-%m-%d')

        # coll.insert_many([payload])
        coll.find_one_and_update({'job_link': payload['job_link']}, {'$set': payload}, upsert= True)

    channel.basic_consume(
        queue='mongoJobsSave', on_message_callback=callback, auto_ack=False)

    print(' [*] Waiting for messages. To exit press CTRL+C')
    channel.start_consuming()

except Exception as e:
    error = {
        "status": "Shine......... Error occured while saving jobs",
        "errorMsg": e
    }
    print("Error: ",error)
    # message = 'Subject: {}\n\n{}'.format("Gigs4me Job Error", error)
    # mailSent = sendMail(message)
    # print('Main sent: {}'.format(mailSent))
