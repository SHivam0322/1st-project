import logging
from datetime import datetime
# import numpy
# import six
from dotenv import load_dotenv
import os
import json
import pika
import requests
try: 
    load_dotenv()
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    channel.queue_declare(queue='nlp')

    #code starts here 
    def callback(ch, method, properties, body):
        data = json.loads(body)
        nlu_url =  os.getenv('NLU_URL')
        querystring = {"min_confidence":"0","text": data['description'],"country":"-1","social":"False","top_entities":"8","include":"image%2Cabstract%2Ctypes%2Ccategories%2Clod","token":"cb045fadbb544002986f023ab051bf07"}
        payload = ""
        headers = {
        'content-type': "text/plain",
        'cache-control': "no-cache"
        }
        nlu_response = requests.request("GET", nlu_url, data=payload, headers=headers, params=querystring)
        # print(nlu_response.text)
        res = json.loads(nlu_response.text)
        tags = []
        if 'annotations' in res.keys() and len(res['annotations']) > 0:
            # print(data['annotations'])
            annotations = res['annotations']
            for item in annotations:
                if 'label' in item.keys() and len(item['label']) > 0:
                    # print(item['label'])
                    tags.append(item['label'])
            print(tags)
        data['tags'] = tags
        # print(data)
        # channel.queue_declare(queue='wixJobsSave')
        channel.queue_declare(queue='mongoJobsSave')
        # channel.basic_publish(exchange='', routing_key='wixJobsSave', body=json.dumps(data))
        channel.basic_publish(exchange='', routing_key='mongoJobsSave', body=json.dumps(data))
        print("item processed")

    #Execution starts from here 
    channel.basic_consume(
        queue='nlp', on_message_callback=callback, auto_ack=True)
    print(' [*] Waiting for messages. To exit press CTRL+C')
    channel.start_consuming()

except Exception as e:
    error = {
        "status": "Error occured while processing the nlp part...",
        "errorMsg": e
    }
    print("Error: ",error)