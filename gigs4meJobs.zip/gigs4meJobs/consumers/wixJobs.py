import pika
import json
from pymongo import MongoClient
from datetime import datetime
import requests
from dotenv import load_dotenv
import os

load_dotenv()


try:
    connection = pika.BlockingConnection(
        pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    channel.queue_declare(queue='wixJobsSave')

    def callback(ch, method, properties, body):
        # print(" [x] Received %r" % json.loads(body))
        payload = json.loads(body)
        payload['date'] = datetime.today().strftime('%Y-%m-%d')

        url = os.getenv('WIX_URL')
        headers = {
            'Content-Type': "application/json",
        }
        if 'tags' in payload.keys() and len(payload['tags']) > -1:
            payload['tags'] = ",".join(payload['tags'])
        payload['tags'] = ''
        data = json.dumps(payload)
        response = requests.request("POST", url, data=data, headers=headers)
        print(response.text)

    channel.basic_consume(
        queue='wixJobsSave', on_message_callback=callback, auto_ack=False)

    print(' [*] Waiting for messages. To exit press CTRL+C')
    channel.start_consuming()

except Exception as e:
    error = {
        "status": "Shine......... Error occured while saving jobs",
        "errorMsg": e
    }
    print("Error: ",error)
    # message = 'Subject: {}\n\n{}'.format("Gigs4me Job Error", error)
    # mailSent = sendMail(message)
    # print('Main sent: {}'.format(mailSent))
