from bs4 import BeautifulSoup
import pika
import json
import re
# from lib import sendMail

try:
    connection = pika.BlockingConnection(
        pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    channel.queue_declare(queue='mongoJobsSave')
    channel.queue_declare(queue='wixJobsSave')
    channel.queue_declare(queue='indeedHtmlParse')
    # channel.queue_declare(queue='linkedinFetchJobDetails')


    def callback(ch, method, properties, body):
        # print(" [x] Received %r" % body)
        soup = BeautifulSoup(body, 'html.parser')
        res = soup.find_all("div", class_="jobsearch-SerpJobCard")
        print("Job count before data formation:",len(res))
        print("Creating job data...")
        for item in res:
            job = {}
            job['company'] = ''.join(item.find(class_="company").getText().strip()) if item.find(class_="company") else ''
            job['location'] = re.sub(r"[^a-zA-Z0-9()-/@]+", ' ',item.find(class_="location accessible-contrast-color-location").getText().rstrip()) if item.find(class_="location accessible-contrast-color-location") else ''
            job['title'] = item.find(class_="jobtitle").get('title') if item.find(class_="jobtitle") else ''
            job['salary'] = item.find(class_="salaryText").getText().strip() if item.find(class_="salaryText") else ''
            job['job_link'] = 'https://www.indeed.co.in' + item.find(class_="jobtitle").get('href') if item.find(class_="jobtitle") else ''
            job['link_2'] = ''
            job['experience'] = ''
            job['description'] = ''
            job['source'] = 'indeed'

            if len(job['description']) > 0:
                channel.basic_publish(exchange='', routing_key='nlp', body=json.dumps(job))
            else:
                channel.basic_publish(exchange='', routing_key='mongoJobsSave', body=json.dumps(job))
                channel.basic_publish(exchange='', routing_key='wixJobsSave', body=json.dumps(job))


    channel.basic_consume(
        queue='indeedHtmlParse', on_message_callback=callback, auto_ack=True)

    print(' [*] Waiting for messages. To exit press CTRL+C')
    channel.start_consuming()
except Exception as e:
    error = {
        "status": "Indeed......... Error occured while parsgin html",
        "errorMsg": e
    }
    print("Error: ",error)
    # message = 'Subject: {}\n\n{}'.format("Gigs4me Job Error", error)
    # mailSent = sendMail(message)
    # print('Main sent: {}'.format(mailSent))
