from bs4 import BeautifulSoup
import pika
import json
import requests
import json
# from lib import sendMail

try:
    headers = requests.utils.default_headers()
    headers.update({ 'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0'})


    connection = pika.BlockingConnection(
        pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    channel.queue_declare(queue='linkedinSaveJobs')
    channel.queue_declare(queue='linkedinFetchJobDetails')


    def callback(ch, method, properties, body):
        # print(" [x] Received %r" % json.loads(body))
        job = json.loads(body)
        req = requests.get(job['link_1'], headers)
        soup = BeautifulSoup(req.content, 'html.parser') 
        jobDescription = soup.find("div", class_="description__text description__text--rich").getText().strip() if soup.find("div", class_="description__text description__text--rich") else ''

        job["jobDescription"] = jobDescription

        channel.basic_publish(exchange='', routing_key='linkedinSaveJobs', body=json.dumps(job))

    channel.basic_consume(
        queue='linkedinFetchJobDetails', on_message_callback=callback, auto_ack=True)

    print(' [*] Waiting for messages. To exit press CTRL+C')
    channel.start_consuming()

except Exception as e:
    error = {
        "status": "Linkedin......... Error occured while fetching job details",
        "errorMsg": e
    }
    print("Error: ",error)
    # message = 'Subject: {}\n\n{}'.format("Gigs4me Job Error", error)
    # mailSent = sendMail(message)
    # print('Main sent: {}'.format(mailSent))